﻿using System;
using Microsoft.Azure.Devices.Common;
using Microsoft.Azure.EventHubs;
using System.Text;
using System.Threading;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Newtonsoft.Json;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace SmartFarmIotHub
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
        private async void ShowMessage(string msg, string title)
        {
            var messageDialog = new MessageDialog(msg, title);
            await messageDialog.ShowAsync();
        }






        #region Receiving EventHub Async



        private static CancellationTokenSource ctsForDataReceiving;

        private async void ReceivingEventHubAsync(string selectedDevice, CancellationToken ct)
        {
            EventHubClient eventHubClient = null;
            PartitionReceiver eventHubReceiver = null;
            string consumerGroupName = "$Default";
            try
            {
                int messagesCount = 0;
                var connectionString = new EventHubsConnectionStringBuilder(new Uri(AzureIoTHub.s_eventHubsCompatibleEndpoint), AzureIoTHub.s_eventHubsCompatiblePath, AzureIoTHub.s_iotHubSasKeyName, AzureIoTHub.s_iotHubSasKey);
                eventHubClient = EventHubClient.CreateFromConnectionString(connectionString.ToString());

                txtMsgReceived.Text = "Receiving messages from devices...\r\n\n";

                var eventHubPartitionsCount = (await eventHubClient.GetRuntimeInformationAsync()).PartitionCount;
                string partition = EventHubPartitionKeyResolver.ResolveToPartition(selectedDevice, eventHubPartitionsCount);

                eventHubReceiver = eventHubClient.CreateReceiver(consumerGroupName, partition, EventPosition.FromEnqueuedTime(DateTime.Now));

                string previousDrynessAlert = string.Empty;
                while (true)
                {
                    ct.ThrowIfCancellationRequested();

                    var events = await eventHubReceiver.ReceiveAsync(int.MaxValue);
                    if (events == null)
                    {
                        txtMsgReceived.Text += "No messages for receiving!\r\n";
                        continue;
                    }


                    foreach (EventData eventData in events)
                    {
                        string data = Encoding.UTF8.GetString(eventData.Body.Array);
                        var enqueuedTime = eventData.SystemProperties.EnqueuedTimeUtc.ToLocalTime();
                        var connectionDeviceId = eventData.SystemProperties["iothub-connection-device-id"].ToString();
                        messagesCount++;

                        if (string.CompareOrdinal(selectedDevice.ToUpper(), connectionDeviceId.ToUpper()) == 0)
                        {
                            txtMsgReceived.Text += $"{messagesCount} - {enqueuedTime} Device: [{connectionDeviceId}], Sensors Data : [ {data} ]";

                            if (eventData.Properties.Count > 0)
                            {
                                txtMsgReceived.Text += "Properties: ";

                                foreach (var property in eventData.Properties)
                                {
                                    txtMsgReceived.Text += $"'{property.Key}' : '{property.Value}'\n\r";
                                    if (property.Key == "DrynessAlert")
                                    {
                                        string currentDrynessAlert = property.Value.ToString().ToLower();

                                        if (previousDrynessAlert != currentDrynessAlert)
                                        {
                                            previousDrynessAlert = currentDrynessAlert;

                                            if (property.Value.ToString().ToLower() == true.ToString().ToLower())
                                                await AzureIoTHub.InvokeDirectMethod(AzureIoTHub.DirectMethodAction.StartWaterPump);
                                            else
                                                await AzureIoTHub.InvokeDirectMethod(AzureIoTHub.DirectMethodAction.StopWaterPump);
                                        }

                                    }
                                }
                            }

                            //txtMsgReceived.Text += "\n-------------------------------------------------------------------------------------------------------------------\r\n";
                        }
                    }

                }

            }
            catch (Exception ex)
            {
                if (ct.IsCancellationRequested)
                {
                    txtMsgReceived.Text += $"Stopped receiving data. {ex.Message}\r\n";
                    ShowMessage("Data receiving was stopped by user!", "Stop Receiving Data");
                }
                else
                {
                    txtMsgReceived.Text += $"Stopped receiving data. {ex.Message}\r\n";
                    ShowMessage(ex.Message, "Error Message");
                }
                if (eventHubReceiver != null)
                {
                    eventHubReceiver.Close();
                }
                if (eventHubClient != null)
                {
                    eventHubClient.Close();
                }

            }
        }


        #endregion



        private async void BtnSetThresholds_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double moistureThreshold;
                double temperatureThreshold;
                double humidityThreshold;

                var SensorData = new
                {
                    MoistureThreshold = txtMoistureThreshold.Text,
                    TemperatureThreshold = txtTemperatureThreshold.Text,
                    HumidityThreshold = txtHumidityThreshold.Text
                };
                if ((double.TryParse(SensorData.MoistureThreshold, out moistureThreshold) && (moistureThreshold >= 0 && moistureThreshold <= 100)) &&
                    ((SensorData.TemperatureThreshold.IsNullOrWhiteSpace()) || (double.TryParse(SensorData.TemperatureThreshold, out temperatureThreshold) && (temperatureThreshold >= -60 && temperatureThreshold <= 100))) &&
                    ((SensorData.HumidityThreshold.IsNullOrWhiteSpace()) || (double.TryParse(SensorData.HumidityThreshold, out humidityThreshold) && (humidityThreshold >= 0 && humidityThreshold <= 100))))
                {
                    var payloadString = JsonConvert.SerializeObject(SensorData);
                    await AzureIoTHub.InvokeDirectMethod(AzureIoTHub.DirectMethodAction.SetThresholds, payloadString);
                }
                else
                    throw new Exception("Threshold values must be correct", new Exception("Invalid Entered Values"));
            }
            catch (Exception ex)
            {
                string title = "Error";
                if (ex.InnerException != null && ex.InnerException.Message == "Invalid Entered Values")
                    title = "Invalid Entered Values";
                ShowMessage(ex.Message, title);
            }
        }

        private async void ToggleWaterPumpg_Toggled(object sender, RoutedEventArgs e)
        {
            ToggleSwitch toggleSwitch = sender as ToggleSwitch;
            try
            {
                if (toggleSwitch.IsOn)
                {
                    await AzureIoTHub.InvokeDirectMethod(AzureIoTHub.DirectMethodAction.StartWaterPump);
                }
                else
                {
                    await AzureIoTHub.InvokeDirectMethod(AzureIoTHub.DirectMethodAction.StopWaterPump);
                }
            }
            catch (Exception ex)
            {
                ShowMessage(ex.Message, "Error");
            }

        }

        private async void ToggleFarmLighting_Toggled(object sender, RoutedEventArgs e)
        {
            ToggleSwitch toggleSwitch = sender as ToggleSwitch;
            try
            {
                if (toggleSwitch.IsOn)
                {
                    await AzureIoTHub.InvokeDirectMethod(AzureIoTHub.DirectMethodAction.TurnOnFarmLight);
                }
                else
                {
                    await AzureIoTHub.InvokeDirectMethod(AzureIoTHub.DirectMethodAction.TurnOffFarmLight);
                }
            }
            catch (Exception ex)
            {
                ShowMessage(ex.Message, "Error");
            }
        }

        private void ToggleReceivingSensorData_Toggled(object sender, RoutedEventArgs e)
        {
            ToggleSwitch toggleSwitch = sender as ToggleSwitch;
            if (toggleSwitch.IsOn == true)
            {
                ctsForDataReceiving = new CancellationTokenSource();
                ReceivingEventHubAsync("WaterPump", ctsForDataReceiving.Token);

            }
            else
            {
                ctsForDataReceiving.Cancel();
            }
        }

        private async void ToggleSendingSensorData_Toggled(object sender, RoutedEventArgs e)
        {
            ToggleSwitch toggleSwitch = sender as ToggleSwitch;
            try
            {
                if (toggleSwitch.IsOn)
                {
                    await AzureIoTHub.InvokeDirectMethod(AzureIoTHub.DirectMethodAction.StartSendingMsgs);
                }
                else
                {
                    await AzureIoTHub.InvokeDirectMethod(AzureIoTHub.DirectMethodAction.StopSendingMsgs);
                }
            }
            catch (Exception ex)
            {
                ShowMessage(ex.Message, "Error");
            }

        }

        private async void BtnSetMessagesCount_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int maxNoOfSentMessages;

                if (int.TryParse(txtMessagesCount.Text, out maxNoOfSentMessages) && (maxNoOfSentMessages >= 1 && maxNoOfSentMessages <= 200))
                {
                    await AzureIoTHub.InvokeDirectMethod(AzureIoTHub.DirectMethodAction.SetMaxMsgsCount, txtMessagesCount.Text);
                }
                else
                    throw new Exception("Values must be correct", new Exception("Invalid Entered Values"));
            }
            catch (Exception ex)
            {
                string title = "Error";
                if (ex.InnerException != null && ex.InnerException.Message == "Invalid Entered Values")
                    title = "Invalid Entered Values";
                ShowMessage(ex.Message, title);
            }

        }
    }

}
