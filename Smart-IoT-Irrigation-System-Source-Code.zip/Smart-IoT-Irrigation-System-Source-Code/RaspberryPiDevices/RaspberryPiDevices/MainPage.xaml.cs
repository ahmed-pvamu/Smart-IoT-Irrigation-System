﻿using System;
using System.Threading.Tasks;
using RaspberryPiDevices.Services;
using Sensors.Dht;
using Windows.Devices.Gpio;
using Windows.Devices.Spi;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace RaspberryPiDevices
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public partial class MainPage : DevicePage
    {

        private DispatcherTimer _timer = new DispatcherTimer();

        // Water pump images
        BitmapImage bitmapStartIrrigation = new BitmapImage(new Uri("ms-appx:///Assets/start_irrigation.gif"));
        BitmapImage bitmapStopIrrigation = new BitmapImage(new Uri("ms-appx:///Assets/stop_irrigation.gif"));

        // Farm lghting images
        BitmapImage bitmapFarmLightingOn = new BitmapImage(new Uri("ms-appx:///Assets/farm_light_on.gif"));
        BitmapImage bitmapFarmLightingOff = new BitmapImage(new Uri("ms-appx:///Assets/farm_light_off.gif"));

        // Water pump & Lighting text color
        private SolidColorBrush startBrush = new SolidColorBrush(Windows.UI.Colors.GreenYellow);
        private SolidColorBrush stopBrush = new SolidColorBrush(Windows.UI.Colors.LightGray);

        // Water pump GPIO
        private GpioPin pin4 = null;
        private const int WATER_PUMP_PIN = 4;

        // Farm lighting GPIO
        private GpioPin pin5 = null;
        private const int FARM_LIGHTING_PIN = 5;

        // DHT11 Sensor
        private GpioPin pin17 = null;
        private IDht dht11 = null;
        private const int DHT_PIN = 17;

        //SPI 
        private const Int32 SPI_CHIP_SELECT_LINE = 0;
        byte[] readBuffer = new byte[3];
        byte[] writeBuffer = new byte[3] { 0x68, 0x00, 0x00 };
        private SpiDevice SpiDisplay = null;

        // Sensors data properties
        private double temperature = 0;
        public double Temperature
        {
            get
            {
                return temperature;
            }
            set
            {

                if (value != -1)
                {
                    this.SetProperty(ref temperature, value);
                }
            }
        }

        private double humidity = 0;
        public double Humidity
        {
            get
            {
                return humidity;
            }
            set
            {
                if (value != -1)
                {
                    this.SetProperty(ref humidity, value);
                }
            }
        }

        private double moisture = 0;
        public double Moisture
        {
            get
            {
                return moisture;
            }
            set
            {
                if (value != -1)
                {
                    this.SetProperty(ref moisture, value);
                }
            }
        }

        bool previousWaterPumpOn = false;
        bool previousFarmLightOn = false;


        public MainPage()
        {
            InitializeComponent();

            
            imgStartStopIrrigation.Source = bitmapStopIrrigation;
            txtStartStopIrrigation.Text = "Water Pump Stopped";
            txtStartStopIrrigation.Foreground = stopBrush;

            imgLightingOnOff.Source = bitmapFarmLightingOff;
            txtLightingOnOff.Text = "Farm Lighting is Off";
            txtLightingOnOff.Foreground = stopBrush;


            _timer.Interval = TimeSpan.FromSeconds(2);
            _timer.Tick += this.Timer_Tick;
        }

        private async void InitializeSPI()
        {
            try
            {
                var settings = new SpiConnectionSettings(SPI_CHIP_SELECT_LINE);
                settings.ClockFrequency = 500000; // 10000000;
                settings.Mode = SpiMode.Mode0;
                var controller = await SpiController.GetDefaultAsync();
                SpiDisplay = controller.GetDevice(settings);
            }

            /* If initialization fails, display the exception and stop running */
            catch (Exception ex)
            {
                throw new Exception("SPI Initialization Failed", ex);
            }
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            // Initialize SPI
            InitializeSPI();

            // initialize GPIO
            GpioController gpioController = GpioController.GetDefault();
            if (gpioController != null)
            {
                pin17 = gpioController.OpenPin(DHT_PIN, GpioSharingMode.Exclusive);
                dht11 = new Dht11(pin17, GpioPinDriveMode.Input);


                pin4 = gpioController.OpenPin(WATER_PUMP_PIN, GpioSharingMode.Exclusive);
                pin4.Write(GpioPinValue.Low);
                pin4.SetDriveMode(GpioPinDriveMode.Output);


                pin5 = gpioController.OpenPin(FARM_LIGHTING_PIN, GpioSharingMode.Exclusive);
                pin5.Write(GpioPinValue.Low);
                pin5.SetDriveMode(GpioPinDriveMode.Output);
            }

            // Start the timer            
            _timer.Start();

            // Register direct methods
            Task.Run(async () =>
            {

                await AzureIoTHub.RegisterFarmLightDirectMethodsAsync();
                await AzureIoTHub.RegisterWaterPumpDirectMethodsAsync();
                await AzureIoTHub.RegisterSensorsDataThresholdDirectMethodsAsync();
                await AzureIoTHub.RegisterStartStopSendingMessagesDirectMethodsAsync();
                await AzureIoTHub.RegisterSetMaxNoOfSentMessagesDirectMethodsAsync();

                while (true)
                {


                    await this.Dispatcher.RunAsync(CoreDispatcherPriority.High, () =>
                    {
                        txtTresholdsValues.Text ="Moisture: " + AzureIoTHub.MoistureThreshold +
                        (AzureIoTHub.TemperatureThreshold.HasValue ? ", Temperature: " + AzureIoTHub.TemperatureThreshold : string.Empty) +
                        (AzureIoTHub.HumidityThreshold.HasValue ? ", Humidity: " + AzureIoTHub.HumidityThreshold : string.Empty);

                        txtMaxNumberOfMsgs.Text = AzureIoTHub.MaxSentMessageCount.ToString();

                        txtIsSendingData.Text = AzureIoTHub.IsSendingMessages.ToString();
                        if(!AzureIoTHub.IsSendingMessages)
                            txtSentMsgCounter.Text = string.Empty;

                        if (previousWaterPumpOn != AzureIoTHub.WaterPumpOn)
                        {
                            previousWaterPumpOn = AzureIoTHub.WaterPumpOn;
                            StartStopWaterPump(AzureIoTHub.WaterPumpOn);
                        }

                        if (previousFarmLightOn != AzureIoTHub.FarmLightOn)
                        {
                            previousFarmLightOn = AzureIoTHub.FarmLightOn;
                            TurnFarmLightingOnOff(AzureIoTHub.FarmLightOn);
                        }

                    });
                }
            }
            );



        }

        int count = 0;
        bool isValidDht11Reading = false;

        private async void Timer_Tick(object sender, object e)
        {
            // Read moisture sensor 
            this.Moisture = this.ReadMoisture();

            // Read dht11 sensor            
            (this.Temperature, this.Humidity) = await this.ReadTemperatureHumidity(dht11);

            if (AzureIoTHub.IsSendingMessages)
            {
                if (count < AzureIoTHub.MaxSentMessageCount && isValidDht11Reading)
                {
                    AzureIoTHub.SendDeviceToCloudMessagesAsync(this.Moisture, this.Temperature, this.Humidity, "WaterPump");
                    count++;
                    txtSentMsgCounter.Text = " (" + count + ")";
                }
            }
            else
            {
                count = 0;               
            }
        }

        private void StartStopWaterPump(bool isPumpOn)
        {
            if (pin4 != null)
            {
                imgStartStopIrrigation.Source = null;

                if (isPumpOn)
                {
                    pin4.Write(GpioPinValue.High);
                    imgStartStopIrrigation.Source = bitmapStartIrrigation;
                    txtStartStopIrrigation.Text = "Water Pump Started";
                    txtStartStopIrrigation.Foreground = startBrush;
                }
                else
                {
                    pin4.Write(GpioPinValue.Low);
                    imgStartStopIrrigation.Source = bitmapStopIrrigation;
                    txtStartStopIrrigation.Text = "Water Pump Stopped";
                    txtStartStopIrrigation.Foreground = stopBrush;
                }
            }
        }

        private void TurnFarmLightingOnOff(bool isLighOn)
        {
            if (pin5 != null)
            {
                imgLightingOnOff.Source = null;
                if (isLighOn)
                {
                    pin5.Write(GpioPinValue.High);
                    imgLightingOnOff.Source = bitmapFarmLightingOn;
                    txtLightingOnOff.Text = "Farm Lighting is On";
                    txtLightingOnOff.Foreground = startBrush;
                }
                else
                {
                    pin5.Write(GpioPinValue.Low);
                    imgLightingOnOff.Source = bitmapFarmLightingOff;
                    txtLightingOnOff.Text = "Farm Lighting is Off";
                    txtLightingOnOff.Foreground = stopBrush;
                }
            }
        }
        protected async Task<(double Temperature, double Humidity)> ReadTemperatureHumidity(IDht sensor)
        {
            (double Temperature, double Humidity) temperatureHumidityValue = (0, 0);

            DhtReading dht11Reading = new DhtReading();
            dht11Reading = await sensor.GetReadingAsync().AsTask();

            if (dht11Reading.IsValid)
            {
                isValidDht11Reading = dht11Reading.IsValid;
                temperatureHumidityValue.Temperature = dht11Reading.Temperature;
                temperatureHumidityValue.Humidity = dht11Reading.Humidity;
            }
            else
            {
                temperatureHumidityValue.Temperature = -1;
                temperatureHumidityValue.Humidity = -1;
            }

            return temperatureHumidityValue;
        }

        protected int ReadMoisture()
        {
            SpiDisplay.TransferFullDuplex(writeBuffer, readBuffer);
            int result = readBuffer[0] & 0x03;
            result <<= 8;
            result += readBuffer[1];
            return (result * 100) / 1023;// to convert it in perentage the high percentage is the more dry

        }

    }
}
