﻿using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace RaspberryPiDevices
{
    public static class AzureIoTHub
    {

        static DeviceClient lightingDeviceClient = null;
        static DeviceClient waterPumpDeviceClient = null;

        const string lightingDeviceConnectionString = "HostName=PvamuIotHub.azure-devices.net;DeviceId=LightingLED;SharedAccessKey=60aWXjlNGGAaQL7/StHtbeBi0ZHmz7FKK+7ktrkfvM8=";
        const string waterPumpDeviceConnectionString = "HostName=PvamuIotHub.azure-devices.net;DeviceId=WaterPump;SharedAccessKey=n6iVKzhQGG/L+P0E2gMC1FKsB8YoaYPgi/Fjj2ARgJk=";

        public static bool WaterPumpOn = false;
        public static bool FarmLightOn = false;

        // Sensors thresholds
        public static double? MoistureThreshold = 70;
        public static double? TemperatureThreshold = null;
        public static double? HumidityThreshold = null;


        // sent messages setting
        public static bool IsSendingMessages = false;
        public static int MaxSentMessageCount = 30;




        private static void CreateClient(string deviceId)
        {
            if (lightingDeviceClient == null && deviceId == "LightingLED")
            {
                lightingDeviceClient = DeviceClient.CreateFromConnectionString(lightingDeviceConnectionString, TransportType.Mqtt);
            }
            else if (waterPumpDeviceClient == null && deviceId == "WaterPump")
            {
                waterPumpDeviceClient = DeviceClient.CreateFromConnectionString(waterPumpDeviceConnectionString, TransportType.Mqtt);
            }
        }

        private static async Task<MethodResponse> OnTurnOnOffFarmLightCalled(MethodRequest methodRequest, object userContext)
        {
            Task<MethodResponse> getResponse = null;
            var data = Encoding.UTF8.GetString(methodRequest.Data);

            if (bool.TryParse(data, out FarmLightOn))
            {
                string result = "{\"result\":\"Executed direct method by Raspberri pi 3 : " + methodRequest.Name + "\"}";

                getResponse = Task.FromResult(new MethodResponse(Encoding.UTF8.GetBytes(result), 200));
            }
            else
            {
                string result = "{\"result\":\"Invalid parameter\"}";
                getResponse = Task.FromResult(new MethodResponse(Encoding.UTF8.GetBytes(result), 400));
            }

            MethodResponse response = await getResponse;
            return response;
        }

        private static async Task<MethodResponse> OnStartStopWaterPumpCalled(MethodRequest methodRequest, object userContext)
        {
            Task<MethodResponse> getResponse = null;
            var data = Encoding.UTF8.GetString(methodRequest.Data);

            if (bool.TryParse(data, out WaterPumpOn))
            {
                string result = "{\"result\":\"Executed direct method by Raspberri pi 3 : " + methodRequest.Name + "\"}";

                getResponse = Task.FromResult(new MethodResponse(Encoding.UTF8.GetBytes(result), 200));
            }
            else
            {
                string result = "{\"result\":\"Invalid parameter\"}";
                getResponse = Task.FromResult(new MethodResponse(Encoding.UTF8.GetBytes(result), 400));
            }

            MethodResponse response = await getResponse;
            return response;
        }

        private static async Task<MethodResponse> OnSetThresholdsCalled(MethodRequest methodRequest, object userContext)
        {
            Task<MethodResponse> getResponse = null;

            double moistureThreshold;
            double temperatureThreshold;
            double humidityThreshold;



            JObject sensorsThresoldsObject = JObject.Parse(methodRequest.DataAsJson);

            string sentTemperatureThreshold = sensorsThresoldsObject.GetValue("TemperatureThreshold").ToString();
            string sentHumidityThreshold = sensorsThresoldsObject.GetValue("HumidityThreshold").ToString();

            if ((double.TryParse(sensorsThresoldsObject.GetValue("MoistureThreshold").ToString(), out moistureThreshold)) &&
                (string.IsNullOrWhiteSpace(sentTemperatureThreshold) || (double.TryParse(sentTemperatureThreshold, out temperatureThreshold))) &&
                (string.IsNullOrWhiteSpace(sentHumidityThreshold) || (double.TryParse(sentHumidityThreshold, out humidityThreshold)))
                )
            {
                MoistureThreshold = moistureThreshold;
                if (!string.IsNullOrWhiteSpace(sentTemperatureThreshold))
                    TemperatureThreshold = double.Parse(sentTemperatureThreshold);
                else
                    TemperatureThreshold = null;

                if (!string.IsNullOrWhiteSpace(sentHumidityThreshold))
                    HumidityThreshold = double.Parse(sentHumidityThreshold);
                else
                    HumidityThreshold = null;

                string result = "{\"result\":\"Executed direct method by Raspberri pi 3 : " + methodRequest.Name + "\"}";
                getResponse = Task.FromResult(new MethodResponse(Encoding.UTF8.GetBytes(result), 200));
            }
            else
            {
                string result = "{\"result\":\"Invalid parameter\"}";
                getResponse = Task.FromResult(new MethodResponse(Encoding.UTF8.GetBytes(result), 400));
            }

            MethodResponse response = await getResponse;
            return response;
        }

        private static async Task<MethodResponse> OnStartStopSendingMessagesCalled(MethodRequest methodRequest, object userContext)
        {
            Task<MethodResponse> getResponse = null;
            var data = Encoding.UTF8.GetString(methodRequest.Data);

            if (bool.TryParse(data, out IsSendingMessages))
            {
                string result = "{\"result\":\"Executed direct method by Raspberri pi 3 : " + methodRequest.Name + "\"}";

                getResponse = Task.FromResult(new MethodResponse(Encoding.UTF8.GetBytes(result), 200));
            }
            else
            {
                string result = "{\"result\":\"Invalid parameter\"}";
                getResponse = Task.FromResult(new MethodResponse(Encoding.UTF8.GetBytes(result), 400));
            }

            MethodResponse response = await getResponse;
            return response;
        }

        private static async Task<MethodResponse> OnSetMaxNoOfSentMessagesCountCalled(MethodRequest methodRequest, object userContext)
        {
            Task<MethodResponse> getResponse = null;
            var data = Encoding.UTF8.GetString(methodRequest.Data);

            if (int.TryParse(data, out MaxSentMessageCount))
            {
                string result = "{\"result\":\"Executed direct method by Raspberri pi 3 : " + methodRequest.Name + "\"}";

                getResponse = Task.FromResult(new MethodResponse(Encoding.UTF8.GetBytes(result), 200));
            }
            else
            {
                string result = "{\"result\":\"Invalid parameter\"}";
                getResponse = Task.FromResult(new MethodResponse(Encoding.UTF8.GetBytes(result), 400));
            }

            MethodResponse response = await getResponse;
            return response;
        }

        public static async Task RegisterFarmLightDirectMethodsAsync()
        {
            CreateClient("LightingLED");
            await lightingDeviceClient.SetMethodHandlerAsync("TurnOnOffFarmLight", OnTurnOnOffFarmLightCalled, null);
        }

        public static async Task RegisterWaterPumpDirectMethodsAsync()
        {
            CreateClient("WaterPump");
            await waterPumpDeviceClient.SetMethodHandlerAsync("StartStopWaterPump", OnStartStopWaterPumpCalled, null);
        }

        public static async Task RegisterSensorsDataThresholdDirectMethodsAsync()
        {
            CreateClient("WaterPump");
            await waterPumpDeviceClient.SetMethodHandlerAsync("SetThresholds", OnSetThresholdsCalled, null);
        }

        public static async Task RegisterStartStopSendingMessagesDirectMethodsAsync()
        {
            CreateClient("WaterPump");
            await waterPumpDeviceClient.SetMethodHandlerAsync("SetStartStopSendingMessages", OnStartStopSendingMessagesCalled, null);
        }

        public static async Task RegisterSetMaxNoOfSentMessagesDirectMethodsAsync()
        {
            CreateClient("WaterPump");
            await waterPumpDeviceClient.SetMethodHandlerAsync("SetMaxNoOfSentMessage", OnSetMaxNoOfSentMessagesCountCalled, null);
        }



        public static async void SendDeviceToCloudMessagesAsync(double moisture, double temperature, double humidity, string deviceId)
        {
            CreateClient(deviceId);

            // Create JSON message
            var telemetryDataPoint = new
            {
                Moisture = moisture,
                Temperature = temperature,
                Humidity = humidity,
                DevicId = deviceId
            };
            var messageString = JsonConvert.SerializeObject(telemetryDataPoint);
            var message = new Message(Encoding.ASCII.GetBytes(messageString));

            // Add a custom application property to the message.
            // An IoT hub can filter on these properties without access to the message body.

            message.Properties.Add("DrynessAlert", (moisture >= MoistureThreshold) ? "true" : "false");

            // Send the telemetry message
            //await Task.Delay(TimeSpan.FromSeconds(3));
            await waterPumpDeviceClient.SendEventAsync(message);
        }

    }
}
