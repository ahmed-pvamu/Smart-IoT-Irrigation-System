﻿using System;
using System.Threading.Tasks;
using Microsoft.Azure.Devices;


public static class AzureIoTHub
{
    public enum DirectMethodAction
    {
        TurnOnFarmLight = 0,
        TurnOffFarmLight = 1,
        StartWaterPump = 2,
        StopWaterPump = 3,
        SetThresholds = 4,
        StartSendingMsgs = 5,
        StopSendingMsgs = 6,
        SetMaxMsgsCount = 7
    }


    private static ServiceClient s_serviceClient;


    const string iotHubConnectionString = "HostName=PvamuIotHub.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=XrZHg96s0JKwl1irO+dvm/tfgYfCzSQbqqrGWrIpFZs=";


    private static async Task InvokeTurnOnOffFarmLightMethod(string isOn)
    {
        var methodInvocation = new CloudToDeviceMethod("TurnOnOffFarmLight") { ResponseTimeout = TimeSpan.FromSeconds(30) };
        methodInvocation.SetPayloadJson(isOn);
        CloudToDeviceMethodResult response = await s_serviceClient.InvokeDeviceMethodAsync("LightingLED", methodInvocation);
    }

    private static async Task InvokeSatrtStopWaterPumpMethod(string isOn)
    {
        var methodInvocation = new CloudToDeviceMethod("StartStopWaterPump") { ResponseTimeout = TimeSpan.FromSeconds(30) };
        methodInvocation.SetPayloadJson(isOn);
        CloudToDeviceMethodResult response = await s_serviceClient.InvokeDeviceMethodAsync("WaterPump", methodInvocation);
    }

    private static async Task InvokeSetThresholdsMethod(string payload)
    {
        var methodInvocation = new CloudToDeviceMethod("SetThresholds") { ResponseTimeout = TimeSpan.FromSeconds(30) };
        methodInvocation.SetPayloadJson(payload);
        CloudToDeviceMethodResult response = await s_serviceClient.InvokeDeviceMethodAsync("WaterPump", methodInvocation);
    }

    private static async Task InvokeStartStopSendingMessagesMethod(string isOn)
    {
        var methodInvocation = new CloudToDeviceMethod("SetStartStopSendingMessages") { ResponseTimeout = TimeSpan.FromSeconds(30) };
        methodInvocation.SetPayloadJson(isOn);
        CloudToDeviceMethodResult response = await s_serviceClient.InvokeDeviceMethodAsync("WaterPump", methodInvocation);
    }

    private static async Task InvokeSetMaxNoOfSentMessagesMethod(string count)
    {
        var methodInvocation = new CloudToDeviceMethod("SetMaxNoOfSentMessage") { ResponseTimeout = TimeSpan.FromSeconds(30) };
        methodInvocation.SetPayloadJson(count);
        CloudToDeviceMethodResult response = await s_serviceClient.InvokeDeviceMethodAsync("WaterPump", methodInvocation);
    }
    public static async Task InvokeDirectMethod(DirectMethodAction directMethoAction, string payLoad = "")
    {
        s_serviceClient = ServiceClient.CreateFromConnectionString(iotHubConnectionString);
        if (directMethoAction == DirectMethodAction.TurnOnFarmLight)
        {
            await InvokeTurnOnOffFarmLightMethod("true");
        }
        else if (directMethoAction == DirectMethodAction.TurnOffFarmLight)
        {
            await InvokeTurnOnOffFarmLightMethod("false");
        }
        else if (directMethoAction == DirectMethodAction.StartWaterPump)
        {
            await InvokeSatrtStopWaterPumpMethod("true");
        }
        else if (directMethoAction == DirectMethodAction.StopWaterPump)
        {
            await InvokeSatrtStopWaterPumpMethod("false");
        }
        else if (directMethoAction == DirectMethodAction.SetThresholds)
        {
            await InvokeSetThresholdsMethod(payLoad);
        }
        else if (directMethoAction == DirectMethodAction.StartSendingMsgs)
        {
            await InvokeStartStopSendingMessagesMethod("true");
        }
        else if (directMethoAction == DirectMethodAction.StopSendingMsgs)
        {
            await InvokeStartStopSendingMessagesMethod("false");
        }
        else if (directMethoAction == DirectMethodAction.SetMaxMsgsCount)
        {
            await InvokeSetMaxNoOfSentMessagesMethod(payLoad);
        }
    }
}

