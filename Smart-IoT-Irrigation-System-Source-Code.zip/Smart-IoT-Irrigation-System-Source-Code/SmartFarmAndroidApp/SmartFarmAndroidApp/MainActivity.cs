﻿using Android.App;
using Android.OS;
using Android.Support.V7.App;
using Android.Runtime;
using Android.Widget;
using Android.Speech;
using Android.Content;
using Android.Speech.Tts;
using Android.Support.Design.Widget;
using System.Globalization;
using Java.Lang;
using Exception = System.Exception;

namespace SmartFarmAndroidApp
{
    //[Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    [Activity(MainLauncher = true)]
    public class MainActivity : AppCompatActivity, TextToSpeech.IOnInitListener, IRunnable
    {
        private ToggleButton toggleStartStopWaterPump;
        private ToggleButton toggleTurnOnOffFarmLight;
        private Button btnTabToSay;
        TextInputEditText txtInputWhatJustSaid;

        TextToSpeech textToSpeech = null;
        private readonly int VOICE = 10;
        Java.Util.Locale language;


        protected override void OnCreate(Bundle savedInstanceState)
        {
            RequestWindowFeature(Android.Views.WindowFeatures.NoTitle);


            base.OnCreate(savedInstanceState);
            

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.activity_main);


            toggleStartStopWaterPump = FindViewById<ToggleButton>(Resource.Id.toggleStartStopWaterPump);
            toggleTurnOnOffFarmLight = FindViewById<ToggleButton>(Resource.Id.toggleTurnOnOffFarmLight);
            btnTabToSay = FindViewById<Button>(Resource.Id.btnTabToSay);
            txtInputWhatJustSaid = FindViewById<TextInputEditText>(Resource.Id.txtInputWhatJustSaid);

            textToSpeech = new TextToSpeech(this, this, "com.google.android.tts");
            language = Java.Util.Locale.Default;
            textToSpeech.SetLanguage(language);
            
            // water pump toggled

            toggleStartStopWaterPump.Click += async (o, e) =>
            {
                try
                {
                    if (toggleStartStopWaterPump.Checked)
                        await AzureIoTHub.InvokeDirectMethod(AzureIoTHub.DirectMethodAction.StartWaterPump);
                    else
                        await AzureIoTHub.InvokeDirectMethod(AzureIoTHub.DirectMethodAction.StopWaterPump);
                }
                catch (Exception ex)
                {
                    Toast.MakeText(this, "Error: " + ex.Message, ToastLength.Long).Show();
                }
            };

            // farm light toggled            
            toggleTurnOnOffFarmLight.Click += async (o, e) =>
            {
                try
                {
                    if (toggleTurnOnOffFarmLight.Checked)
                        await AzureIoTHub.InvokeDirectMethod(AzureIoTHub.DirectMethodAction.TurnOnFarmLight);
                    else
                        await AzureIoTHub.InvokeDirectMethod(AzureIoTHub.DirectMethodAction.TurnOffFarmLight);
                }
                catch (Exception ex)
                {
                    Toast.MakeText(this, "Error: " + ex.Message, ToastLength.Long).Show();
                }
            };

            // Tab to say button click
            btnTabToSay.Click += (sender, e) =>
            {

                var voiceIntent = new Intent(RecognizerIntent.ActionRecognizeSpeech);
                voiceIntent.PutExtra(RecognizerIntent.ExtraLanguageModel, RecognizerIntent.LanguageModelFreeForm);



                voiceIntent.PutExtra(RecognizerIntent.ExtraPrompt, Application.Context.GetString(Resource.String.messageSpeakNow));


                voiceIntent.PutExtra(RecognizerIntent.ExtraSpeechInputCompleteSilenceLengthMillis, 1500);
                voiceIntent.PutExtra(RecognizerIntent.ExtraSpeechInputPossiblyCompleteSilenceLengthMillis, 1500);
                voiceIntent.PutExtra(RecognizerIntent.ExtraSpeechInputMinimumLengthMillis, 15000);
                voiceIntent.PutExtra(RecognizerIntent.ExtraMaxResults, 1);

                voiceIntent.PutExtra(RecognizerIntent.ExtraLanguage, Java.Util.Locale.Default);
                StartActivityForResult(voiceIntent, VOICE);
            };
            
        }

        public void OnInit([GeneratedEnum] OperationResult status)
        {
            textToSpeech.SetLanguage(language);
            Run();
        }

        protected override async void OnActivityResult(int requestCode, Result resultVal, Intent data)
        {
            base.OnActivityResult(requestCode, resultVal, data);

            if (requestCode == VOICE)
            {
                if (resultVal == Result.Ok)
                {
                    var matches = data.GetStringArrayListExtra(RecognizerIntent.ExtraResults);
                    if (matches.Count != 0)
                    {
                        string saidText = matches[0];

                        // limit the output to 300 characters
                        if (saidText.Length > 300)
                            saidText = saidText.Substring(0, 300).ToUpperInvariant();
                        txtInputWhatJustSaid.Text = saidText = CapitilizeFirstLetterEachWord(saidText);
                        if (saidText == Application.Context.GetString(Resource.String.farm_water_pump_on))
                        {
                            await AzureIoTHub.InvokeDirectMethod(AzureIoTHub.DirectMethodAction.StartWaterPump);
                        }
                        else if (saidText == Application.Context.GetString(Resource.String.farm_water_pump_off))
                        {
                            await AzureIoTHub.InvokeDirectMethod(AzureIoTHub.DirectMethodAction.StopWaterPump);
                        }
                        else if (saidText == Application.Context.GetString(Resource.String.farm_light_turn_on))
                        {
                            await AzureIoTHub.InvokeDirectMethod(AzureIoTHub.DirectMethodAction.TurnOnFarmLight);
                        }
                        else if (saidText == Application.Context.GetString(Resource.String.farm_light_turn_off))
                        {
                            await AzureIoTHub.InvokeDirectMethod(AzureIoTHub.DirectMethodAction.TurnOffFarmLight);
                        }

                    }
                    else
                        txtInputWhatJustSaid.Text = "No speech was recognised";

                }
            }
        }

        public void Run()
        {            
            string msgVoiceWelcome = Application.Context.GetString(Resource.String.messageVoiceWelocome);
#pragma warning disable CS0618 // Type or member is obsolete
            textToSpeech.Speak(msgVoiceWelcome, QueueMode.Flush, null);
#pragma warning restore CS0618 // Type or member is obsolete
            Toast.MakeText(this, msgVoiceWelcome, ToastLength.Short).Show();            
        }

        private string CapitilizeFirstLetterEachWord(string text)
        {
            TextInfo UsaTextInfo = new CultureInfo("en-US", false).TextInfo;
            string capitalized = UsaTextInfo.ToTitleCase(text);
            return capitalized;
        }
    }
}